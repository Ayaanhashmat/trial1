function sendMessage(event) {
    if (event.key === "Enter") {
        const userInput = document.getElementById("user-input").value;
        const chatDisplay = document.getElementById("chat-display");

        // Display user's message
        chatDisplay.innerHTML += `<p style="text-align: right;">You: ${userInput}</p>`;
        document.getElementById("user-input").value = "";

        // Send user's message to the server using AJAX/Fetch
        fetch('/chat', {
            method: 'POST',
            body: JSON.stringify({ message: userInput }),
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            // Display the server's response
            chatDisplay.innerHTML += `<p>Server: ${data.response}</p>`;
        })
        .catch(error => {
            console.error('Error:', error);
        });

        // Scroll to the bottom to show the latest messages
        chatDisplay.scrollTop = chatDisplay.scrollHeight;
    }
}
